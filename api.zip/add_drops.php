<?php
$file = 'dating-app (2).sql';

if (file_exists($file)) {
    $content = file_get_contents($file);
    
    // Add DROP PROCEDURE IF EXISTS before CREATE PROCEDURE
    $content = preg_replace('/CREATE\s+PROCEDURE\s+(`[^`]+`)/i', "DROP PROCEDURE IF EXISTS $1;\nCREATE PROCEDURE $1", $content);
    
    // Add DROP TABLE IF EXISTS before CREATE TABLE
    $content = preg_replace('/CREATE\s+TABLE\s+(`[^`]+`)/i', "DROP TABLE IF EXISTS $1;\nCREATE TABLE $1", $content);
    
    file_put_contents($file, $content);
    echo "Added DROP IF EXISTS statements to '$file'.\n";
} else {
    echo "File not found.";
}
