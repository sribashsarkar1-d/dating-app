<?php
$files = ['dating-app.sql', 'dating-app (2).sql'];

foreach ($files as $file) {
    if (file_exists($file)) {
        $content = file_get_contents($file);
        
        // Remove DEFAULT uuid() - case insensitive
        $content = preg_replace('/DEFAULT\s+uuid\(\)/i', '', $content);
        
        file_put_contents($file, $content);
        echo "Removed DEFAULT uuid() from '$file'.\n";
    }
}
