<?php
$file = 'dating-app (2).sql';

if (!file_exists($file)) {
    die("File not found: $file\n");
}

$content = file_get_contents($file);

// Remove DEFINER=`root`@`localhost`
// The pattern accounts for any user and host, e.g., DEFINER=`username`@`%`
$pattern = '/\s*DEFINER\s*=\s*`[^`]+`@`[^`]+`\s*/i';
$replacement = ' ';

$content = preg_replace($pattern, $replacement, $content);

file_put_contents($file, $content);
echo "Removed DEFINER from '$file'.\n";
