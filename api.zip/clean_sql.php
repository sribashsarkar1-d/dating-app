<?php
$file = 'dating-app (3).sql';

if (file_exists($file)) {
    $content = file_get_contents($file);
    
    // 1. Remove DEFINER
    $content = preg_replace('/\\s*DEFINER\\s*=\\s*`[^`]+`@`[^`]+`\\s*/i', ' ', $content);
    
    // 2. Remove DEFAULT uuid() for MySQL 5.7 compatibility
    $content = preg_replace('/DEFAULT\\s+uuid\\(\\)/i', '', $content);
    
    // 3. Add DROP PROCEDURE IF EXISTS before CREATE PROCEDURE
    $content = preg_replace('/CREATE\\s+PROCEDURE\\s+(`[^`]+`)/i', "DROP PROCEDURE IF EXISTS $1;\nCREATE PROCEDURE $1", $content);
    
    // 4. Add DROP TABLE IF EXISTS before CREATE TABLE
    $content = preg_replace('/CREATE\\s+TABLE\\s+(`[^`]+`)/i', "DROP TABLE IF EXISTS $1;\nCREATE TABLE $1", $content);
    
    file_put_contents($file, $content);
    echo "SQL file completely cleaned and prepared for import.\n";
} else {
    echo "File not found: $file\n";
}
